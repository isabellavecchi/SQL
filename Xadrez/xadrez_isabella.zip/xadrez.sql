--BEGIN TRANSACTION;

--Xadrez

CREATE SEQUENCE partida_seq
    MINVALUE 0
    START WITH 0
    INCREMENT BY 1;

--DROP SEQUENCE jogada_seq
CREATE SEQUENCE jogada_seq
    MINVALUE 0
    START WITH 0
    INCREMENT BY 1;

--DROP TABLE tb_peca;
CREATE TABLE tb_peca (
    id_peca         INTEGER,
    cor_peca        CHAR(1)         CHECK (cor_peca in (0, 1)),  -- 1)preta 0)branca
    nome            VARCHAR2(100),
    valor           INTEGER,
    flag_vida       CHAR(1)         CHECK (flag_vida in (0, 1)), -- 1)vivo 0)morto
        CONSTRAINT pk_tb_peca PRIMARY KEY (id_peca)
);

INSERT INTO tb_peca (id_peca, cor_peca, nome, valor, flag_vida)
    VALUES (1, 0, 'torre', 5, 1);
INSERT INTO tb_peca (id_peca, cor_peca, nome, valor, flag_vida)
    VALUES (2, 0, 'cavalo', 3, 1);
INSERT INTO tb_peca (id_peca, cor_peca, nome, valor, flag_vida)
    VALUES (3, 0, 'bispo branco', 3, 1);
INSERT INTO tb_peca (id_peca, cor_peca, nome, valor, flag_vida)
    VALUES (4, 0, 'rei', 0, 1);
INSERT INTO tb_peca (id_peca, cor_peca, nome, valor, flag_vida)
    VALUES (5, 0, 'rainha', 9, 1);
INSERT INTO tb_peca (id_peca, cor_peca, nome, valor, flag_vida)
    VALUES (6, 0, 'bispo preto', 3, 1);
INSERT INTO tb_peca (id_peca, cor_peca, nome, valor, flag_vida)
    VALUES (7, 0, 'cavalo', 3, 1);
INSERT INTO tb_peca (id_peca, cor_peca, nome, valor, flag_vida)
    VALUES (8, 0, 'torre', 5, 1);
    
INSERT INTO tb_peca (id_peca, cor_peca, nome, valor, flag_vida)
    VALUES (9, 0, 'peao', 1, 1);
INSERT INTO tb_peca (id_peca, cor_peca, nome, valor, flag_vida)
    VALUES (10, 0, 'peao', 1, 1);
INSERT INTO tb_peca (id_peca, cor_peca, nome, valor, flag_vida)
    VALUES (11, 0, 'peao', 1, 1);
INSERT INTO tb_peca (id_peca, cor_peca, nome, valor, flag_vida)
    VALUES (12, 0, 'peao', 1, 1);
INSERT INTO tb_peca (id_peca, cor_peca, nome, valor, flag_vida)
    VALUES (13, 0, 'peao', 1, 1);
INSERT INTO tb_peca (id_peca, cor_peca, nome, valor, flag_vida)
    VALUES (14, 0, 'peao', 1, 1);
INSERT INTO tb_peca (id_peca, cor_peca, nome, valor, flag_vida)
    VALUES (15, 0, 'peao', 1, 1);
INSERT INTO tb_peca (id_peca, cor_peca, nome, valor, flag_vida)
    VALUES (16, 0, 'peao', 1, 1);
    
    
INSERT INTO tb_peca (id_peca, cor_peca, nome, valor, flag_vida)
    VALUES (17, 1, 'torre', 5, 1);
INSERT INTO tb_peca (id_peca, cor_peca, nome, valor, flag_vida)
    VALUES (18, 1, 'cavalo', 3, 1);
INSERT INTO tb_peca (id_peca, cor_peca, nome, valor, flag_vida)
    VALUES (19, 1, 'bispo branco', 3, 1);
INSERT INTO tb_peca (id_peca, cor_peca, nome, valor, flag_vida)
    VALUES (20, 1, 'rainha', 0, 1);
INSERT INTO tb_peca (id_peca, cor_peca, nome, valor, flag_vida)
    VALUES (21, 1, 'rei', 9, 1);
INSERT INTO tb_peca (id_peca, cor_peca, nome, valor, flag_vida)
    VALUES (22, 1, 'bispo preto', 3, 1);
INSERT INTO tb_peca (id_peca, cor_peca, nome, valor, flag_vida)
    VALUES (23, 1, 'cavalo', 3, 1);
INSERT INTO tb_peca (id_peca, cor_peca, nome, valor, flag_vida)
    VALUES (24, 1, 'torre', 5, 1);
    
INSERT INTO tb_peca (id_peca, cor_peca, nome, valor, flag_vida)
    VALUES (25, 1, 'peao', 1, 1);
INSERT INTO tb_peca (id_peca, cor_peca, nome, valor, flag_vida)
    VALUES (26, 1, 'peao', 1, 1);
INSERT INTO tb_peca (id_peca, cor_peca, nome, valor, flag_vida)
    VALUES (27, 1, 'peao', 1, 1);
INSERT INTO tb_peca (id_peca, cor_peca, nome, valor, flag_vida)
    VALUES (28, 1, 'peao', 1, 1);
INSERT INTO tb_peca (id_peca, cor_peca, nome, valor, flag_vida)
    VALUES (29, 1, 'peao', 1, 1);
INSERT INTO tb_peca (id_peca, cor_peca, nome, valor, flag_vida)
    VALUES (30, 1, 'peao', 1, 1);
INSERT INTO tb_peca (id_peca, cor_peca, nome, valor, flag_vida)
    VALUES (31, 1, 'peao', 1, 1);
INSERT INTO tb_peca (id_peca, cor_peca, nome, valor, flag_vida)
    VALUES (32, 1, 'peao', 1, 1);

--DROP TABLE tb_jogador;
CREATE TABLE tb_jogador (
    id_jogador      INTEGER,
    username        VARCHAR2(100),
    flag_pessoa     CHAR(1)         CHECK (flag_pessoa in (0,1)),   -- 1)pessoa 0)comp
        CONSTRAINT pk_tb_jogador PRIMARY KEY (id_jogador)
);

INSERT INTO tb_jogador (id_jogador, username, flag_pessoa)
    VALUES (1, 'isabellav', 1);
INSERT INTO tb_jogador (id_jogador, username, flag_pessoa)
    VALUES (2, 'mariaf', 1);
INSERT INTO tb_jogador (id_jogador, username, flag_pessoa)
    VALUES (3, 'flavioc', 1);
INSERT INTO tb_jogador (id_jogador, username, flag_pessoa)
    VALUES (4, 'comp', 0);
    
ALTER TABLE tb_jogador
    ADD (
        vitorias    INTEGER,
        empates     INTEGER,
        derrotas    INTEGER
    );

--AINDA N DEU CERTO, preciso deixar a flag como not null
ALTER TABLE tb_jogador
    MODIFY (
        username        VARCHAR2(100)   UNIQUE NOT NULL
    );

--DROP TABLE tb_partida;
CREATE TABLE tb_partida (
    id_partida      INTEGER,
    id_jogador_1    INTEGER,
    id_jogador_2    INTEGER,
    inicio          DATE        DEFAULT sysdate,        --duvida
    fim             DATE,
        CONSTRAINT pk_tb_partida PRIMARY KEY (id_partida),
        CONSTRAINT fk_tb_partida_jog_1
            FOREIGN KEY (id_jogador_1)
            REFERENCES tb_jogador (id_jogador),
        CONSTRAINT fk_tb_partida_jog_2
            FOREIGN KEY (id_jogador_2)
            REFERENCES tb_jogador (id_jogador)
);

INSERT INTO tb_partida (id_partida, id_jogador_1, id_jogador_2, inicio)
    VALUES(partida_seq.NEXTVAL, 1, 2,SYSDATE);

--inserir id_partida dentro da pk
--DROP table tb_tabuleiro_posicao;
CREATE TABLE tb_tabuleiro_posicao (
    id_partida      INTEGER,
    linha           INTEGER         CHECK (linha BETWEEN 1 AND 8),
    coluna          INTEGER         CHECK (coluna BETWEEN 1 AND 8),
    cor_da_casa     CHAR(1)         CHECK (cor_da_casa in (0,1)),  -- 1)preta 0)branca
    id_peca         INTEGER,
        CONSTRAINT pk_tb_posicao PRIMARY KEY (linha, coluna),
        CONSTRAINT fk_tb_posicao_partida
            FOREIGN KEY (id_partida)
            REFERENCES tb_partida (id_partida),
        CONSTRAINT fk_tb_posicao_peca
            FOREIGN KEY (id_peca)
            REFERENCES tb_peca (id_peca)
);

--vetor
--CREATE OR REPLACE TYPE pecas_brancas IS VARRAY(16) of INTEGER;

CREATE OR REPLACE FUNCTION fn_tabuleiro_inicial
RETURN VARCHAR
AS
--    TYPE pecas brancas   IS VARRAY(16) of NUMERIC(7,3);
    partida         INTEGER;
    i               INTEGER;
    j               INTEGER;
    casa            CHAR(1);
    peca            INTEGER := 0;
BEGIN
    SELECT MAX(p.id_partida)
    INTO partida
    FROM tb_partida p;
    
    FOR i in 1 .. 8 LOOP
        FOR j in 1 .. 8 LOOP
        
            IF MOD((i + j), 2) = 0 THEN
                casa := '0'; --casa branca
            ELSE
                casa := '1'; --casa preta
            END IF;
            
            IF i <= 2 THEN
                peca := peca + 1; --vai de 1 a 16, já na ordem do tabuleiro que foi colocada na tabela
                INSERT INTO tb_tabuleiro_posicao (id_partida, linha, coluna, cor_da_casa, id_peca)
                    VALUES (partida, i, j, casa, peca);
            ELSIF (i > 2 AND i < 7)  THEN
                peca := 33; --o valor da ultima peca +1
                INSERT INTO tb_tabuleiro_posicao (id_partida, linha, coluna, cor_da_casa)
                    VALUES (partida, i, j, casa);
            ELSE
                peca := peca -1; --vai de 32 a 17, já na ordem do tabuleiro que foi colocada na tabela
                INSERT INTO tb_tabuleiro_posicao (id_partida, linha, coluna, cor_da_casa, id_peca)
                    VALUES (partida, i, j, casa, peca);
            END IF;
        END LOOP;
    END LOOP;
    
    RETURN 'Tabuleiro pronto para jogar';
END;
/



--DROP TABLE tb_jogada;
CREATE TABLE tb_jogada (
    id_jogada       INTEGER,
    id_partida      INTEGER,
    id_jogador      INTEGER,
    id_peca         INTEGER,
    mov_horizontal  INTEGER,
    mov_vertical    INTEGER,
    inicio          DATE        DEFAULT sysdate,
        CONSTRAINT pk_tb_jogada PRIMARY KEY (id_jogada),
        CONSTRAINT fk_tb_jogada_partida
            FOREIGN KEY (id_partida)
            REFERENCES tb_partida (id_partida),
        CONSTRAINT fk_jogada_jog
            FOREIGN KEY (id_jogador)
            REFERENCES tb_jogador (id_jogador),
        CONSTRAINT fk_jogada_peca
            FOREIGN KEY (id_peca)
            REFERENCES tb_peca (id_peca)
);

INSERT INTO tb_jogada (id_jogada, id_partida, id_jogador, id_peca, mov_horizontal, mov_vertical)
    VALUES (jogada_seq.NEXTVAL, 2, 1, 12, 0, 2);
INSERT INTO tb_jogada (id_jogada, id_partida, id_jogador, id_peca, mov_horizontal, mov_vertical)
    VALUES (jogada_seq.NEXTVAL, 2, 2, 29, 0, -2);
INSERT INTO tb_jogada (id_jogada, id_partida, id_jogador, id_peca, mov_horizontal, mov_vertical)
    VALUES (jogada_seq.NEXTVAL, 2, 1, 2, 2, 1);
INSERT INTO tb_jogada (id_jogada, id_partida, id_jogador, id_peca, mov_horizontal, mov_vertical)
    VALUES (jogada_seq.NEXTVAL, 2, 2, 28, 0, -1);

INSERT INTO tb_jogada (id_jogada, id_partida, id_jogador, id_peca, mov_horizontal, mov_vertical)
    VALUES (jogada_seq.NEXTVAL, 3, 1, 12, 0, 2);
INSERT INTO tb_jogada (id_jogada, id_partida, id_jogador, id_peca, mov_horizontal, mov_vertical)
    VALUES (jogada_seq.NEXTVAL, 3, 2, 29, 0, -2);
INSERT INTO tb_jogada (id_jogada, id_partida, id_jogador, id_peca, mov_horizontal, mov_vertical)
    VALUES (jogada_seq.NEXTVAL, 3, 1, 2, 2, 1);
INSERT INTO tb_jogada (id_jogada, id_partida, id_jogador, id_peca, mov_horizontal, mov_vertical)
    VALUES (jogada_seq.NEXTVAL, 3, 2, 28, 0, -1);

--DROP TABLE tb_historico;
CREATE TABLE tb_historico (
    id_jogada               INTEGER,
    linha_old               INTEGER,
    coluna_old              INTEGER,
    linha_new               INTEGER,
    coluna_new              INTEGER,
    tempo_de_jogada_seg     NUMBER(8,5),
    comeu                   CHAR(1)     CHECK (comeu in (0,1)),     -- 1)true 0)false
    xeque                   CHAR(1)     CHECK (xeque in (0,1,2)),   -- 0)nao 1)xeque 2)xeque-mate
        CONSTRAINT pk_tb_hstr_jogada PRIMARY KEY (id_jogada),
        CONSTRAINT fk_tb_hstr_jogada
            FOREIGN KEY (id_jogada)
            REFERENCES tb_jogada (id_jogada),
        CONSTRAINT fk_tb_hstr_posicao_old
            FOREIGN KEY (linha_old, coluna_old)
            REFERENCES tb_tabuleiro_posicao (linha, coluna),
        CONSTRAINT fk_tb_hstr_posicao_new
            FOREIGN KEY (linha_new, coluna_new)
            REFERENCES tb_tabuleiro_posicao (linha, coluna)
);

SET SERVEROUTPUT ON;

DECLARE
    inicio      VARCHAR(64);
BEGIN
    dbms_output.enable;
    inicio := fn_tabuleiro_inicial;
    dbms_output.put_line(inicio);
END;
/

--CREATE INDEX idx_partida_jogada_cor
--  ON tb_historico (id_jogada);

CREATE OR REPLACE VIEW jogada_view AS
  SELECT j.id_partida, j.id_jogada, jr.username, p.nome, DECODE(p.cor_peca, 0, 'branca', 1, 'preta'), j.mov_horizontal, j.mov_vertical
    FROM tb_jogada j, tb_peca p, tb_jogador jr
    WHERE j.id_jogador = jr.id_jogador
      AND j.id_peca = p.id_peca
      AND j.id_partida = 2
    ORDER BY j.id_jogada;

SELECT * FROM jogada_view;

ROLLBACK;   --COMMIT;
